 <footer class="site-footer">
    <div class="footer-inner bg-white">
        <div class="row">
            <div class="col-sm-6">
                Copyright &copy; {{ date('Y') . env('APP_NAME')}} 
            </div>
        </div>
    </div>
</footer>
<!-- /.site-footer -->