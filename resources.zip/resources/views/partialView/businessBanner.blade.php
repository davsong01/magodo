  
<div class="business-banner">           			
        <div class="hvrbox">
            <img src="{{asset('images/slider-18.jpg')}}" alt="Church" class="hvrbox-layer_bottom">
            <div class="hvrbox-layer_top">
                <div class="container">
                    <div class="overlay-text text-left">						
                        <h3>@yield('pageTitle')</h3>
                       
                        
                    </div>
                </div>
            </div>
        </div>	                     
    </div>