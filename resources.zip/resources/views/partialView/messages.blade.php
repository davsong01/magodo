<div class="business-blog-1x">  
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="business-title-middle">
                        <h2>Messages</h2>
                        <span class="title-border-middle"></span>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="margin-top-middle"></div>
                </div>
                <div class="col-md-3">
                    <div class="single-bolg hover01">
                        <figure><img src="{{asset('images/blog-1.jpg')}}" alt="slide 1" class=""></figure>
                        <div class="blog-content">
                            <a href="#">WEEP NO MORE (1 Samuel 30:4) Message from Pastor (Dr) E. O. Abina, The General Overseer of GOFAMINT </a>
                            <span><i class="fa fa-clock-o"></i>02 Feb, 2018</span>
                        </div><a href="#" class="btn btn-light" style="font-size:10px; float:right">Read more</a>
                    </div>
                </div>          
                <div class="col-md-3">
                    <div class="single-bolg hover01">
                        <figure><img src="{{asset('images/blog-2.jpg')}}" alt="slide 1" class=""></figure>
                        <div class="blog-content">
                            <a href="#">THANKSGIVING & THANKSLIVING (Dan. 6:10, Ps. 92:1-3, Ps.100:4) By Pastor (Dr) E. O. Abina, The General Overseer of GOFAMINT</a>
                            <span><i class="fa fa-clock-o"></i>14 March, 2018</span>
                        </div><a href="#" class="btn btn-light" style="font-size:10px; float:right">Read more</a>
                    </div>
                </div>          
                <div class="col-md-3">
                    <div class="single-bolg hover01">
                        <figure><img src="{{asset('images/blog-3.jpg')}}" alt="slide 1" class=""></figure>
                        <div class="blog-content">
                            <a href="#">CAN THE CHURCH DELAY OR HASTEN THE RETURN OF THE LORD? (Mt. 24:11-14). By Pastor (Dr) E. O. Abina, The General Overseer of GOFAMINT  </a>
                            <span><i class="fa fa-clock-o"></i>14 April, 2018</span>
                        </div><a href="#" class="btn btn-light" style="font-size:10px; float:right">Read more</a>
                    </div>
                </div>          
                <div class="col-md-3">
                    <div class="single-bolg hover01">
                        <figure><img src="{{asset('images/blog-4.jpg')}}" alt="slide 1" class=""></figure>
                        <div class="blog-content">
                            <a href="#">WELCOME TO MAY 2018 OUR MONTH OF DIVINE REFUGE Psalm 91:1-2 AMPLIFIED</a>
                            <span><i class="fa fa-clock-o"></i>01 May, 2018</span>
                        </div><a href="#" class="btn btn-light" style="font-size:10px; float:right">Read more</a>
                    </div>
                </div>        
            </div><p align="right" style="margin-top:10px;"><a href="#" class="btn btn-danger" style="font-size:10px; position:relative; margin-right:5px; color:#FFF !important">Prev</a><a href="#" class="btn btn-danger" style="font-size:10px; position:relative; color:#FFF !important">Next</a></p>
        </div>
    </div>