				<div class="col-md-3">
                    <div class="padding-top-large"></div>
                    
                    <div class="about-company-right">
                        <div class="right-menubar">
                            <ul>
                                <li><a href="#">QUICK MENU</a></li>
                                <li class="@yield('WelcomeActive')"><a href="{{route('welcome')}}">Welcome Message</a></li>
                                <li class="@yield('MessageActive')"><a href="#">Messages</a></li>
                                <li class="@yield('DeptActive')"><a href="#">Departments</a></li>
                                <li class="@yield('NewsActive')"><a href="#">News and Events</a></li>
                                <li class="@yield('TestimonyActive')"><a href="#">Testimonies</a></li>
                                <li class="@yield('DevoltionActive')"><a href="#">Daily Devotion</a></li>
                                <li class="@yield('RpActive')"><a href="#">Our Regional Pastor</a></li>
                                <li class="@yield('ResPstActive')"><a href="#">Our Resident Pastor</a></li>
                                <li class="@yield('WondersActive')"><a href="#">Wonders Sunday Highlight</a></li>
                            </ul>
                        </div>                        
                        
                        
                        <div class="padding-top-middle"></div> 
                        
                    </div>
                </div>